/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab8.polymorphism;

import javax.swing.JOptionPane;

/**
 *
 * @author pc
 */
public class FractionTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Fraction frac1 = new Fraction(2, 3);
        Fraction frac2 = new Fraction(5, 8);
        Fraction mix1 = new MixedFraction(1, 1, 2);  
        Fraction mix2 = new MixedFraction(3, 2, 5);  

        // Creating array of Fraction objects
        Fraction[] fractionArray = { frac1, frac2, mix1, mix2 };

       
        System.out.println("---- Output to Console ----");
        for (int i = 0; i < fractionArray.length; i++) {
            System.out.println(fractionArray[i].toString());
        }

        
        StringBuilder message = new StringBuilder("---- Output in Message Box ----\n");
        for (Fraction f : fractionArray) {
            message.append(f.toString()).append("\n");
        }

        JOptionPane.showMessageDialog(null, message.toString(), 
            "Lab 8 - Fraction Display", JOptionPane.INFORMATION_MESSAGE);
    }
}

   
