/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package seceretmessageassignment;

import java.util.Scanner;

/**
 *
 * @author pc
 */
public class SecretMessageTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     
        // Test 1
        SecretMessage sample1 = new SecretMessage("The zebra is on the way", 5);
        System.out.println(sample1.toString());
        
        // Test 2
        SecretMessage sample2 = new SecretMessage("Help in danger", 4);
        System.out.println(sample2.toString());
        
        // Test to Takes input from user
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a message to encrypt: ");
        String userMessage = input.nextLine();
        
        System.out.print("Enter displacement value: ");
        int userDisplacement = input.nextInt();
        
        SecretMessage userTest = new SecretMessage(userMessage, userDisplacement);
        System.out.println(userTest.toString());
        
        input.close();
    }
}
    
    

