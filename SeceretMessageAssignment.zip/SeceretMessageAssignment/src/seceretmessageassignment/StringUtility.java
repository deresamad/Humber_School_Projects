/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seceretmessageassignment;

/**
 *
 * @author pc
 */
class StringUtility {
    public static String convertMessage(String message, char[] conversionCode) {
        // Convert input message to character array for processing
        char[] messageChars = message.toCharArray();
        
        // StringBuilder to construct the new converted message
        StringBuilder convertedMessage = new StringBuilder();
        
        // Process each character in the message
        for (char character : messageChars) {
            // Check if character is an uppercase letter (A-Z)
            if (character >= 'A' && character <= 'Z') {
                // Calculate the difference/index using formula: character - 'A'
                // This gives us the position in the alphabet (A=0, B=1, ..., Z=25)
                int difference = character - 'A';
                
                // Use the difference as index to find replacement character
                // in the conversion code array
                char replacementChar = conversionCode[difference];
                convertedMessage.append(replacementChar);
            } else {
                // If not an uppercase letter, keep the character unchanged
                // This preserves spaces, punctuation, and other characters
                convertedMessage.append(character);
            }
        }
        
        // Return the new converted String
        return convertedMessage.toString();
    }
}

