/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seceretmessageassignment;

/**
 *
 * @author pc
 */
class SecretMessage {
    //  Stores the original message
    private String originalMessage;
    
    // Character array for encryption code (rotated alphabet)
    private char[] encode;
    
    // Character array for decryption code (reverse rotated alphabet)
    private char[] decode;
    
    //  Amount of rotation for the cipher
    private int displacement;
    
   
    public SecretMessage(String message, int displacement) {
        this.originalMessage = message;
        this.displacement = displacement;
        this.encode = new char[26];
        this.decode = new char[26];
        
        // To Generate both encryption and decryption codes 
        generateEncryptionCode();
        generateDecryptionCode();
    }
    
    
    private void generateEncryptionCode() {
        for (int index = 0; index < 26; index++) {
            
            encode[index] = (char)(65 + ((index + displacement) % 26));
        }
    }
    
    
    private void generateDecryptionCode() {
        for (int index = 0; index < 26; index++) {
            decode[index] = (char)(65 + ((index - displacement + 26) % 26));
        }
    }
    
    
    public String getSecretMessage() {
        // method to Convert original message to uppercase and call StringUtility method
        return StringUtility.convertMessage(originalMessage.toUpperCase(), encode);
    }
    
    
    public String getDecodedMessage() {
        //method to  First get the secret message, then decrypt it using decryption code
        String secretMessage = getSecretMessage();
        return StringUtility.convertMessage(secretMessage, decode);
    }
    
    
    public char[] getEncryptionCode() {
        return encode;
    }
    
    
    public char[] getDecryptionCode() {
        return decode;
    }
    
    
    public String toString() {
        StringBuilder result = new StringBuilder();
        
        // Display original message
        result.append("Original Message: ").append(originalMessage).append("\n");
        
        // Display encryption code as character array
        result.append("Encryption code: ");
        for (char c : encode) {
            result.append(c);
        }
        result.append("\n");
        
        // Display secret message
        result.append("Secret Message: ").append(getSecretMessage()).append("\n");
        
        // Display decryption code as character array
        result.append("Decryption code: ");
        for (char c : decode) {
            result.append(c);
        }
        result.append("\n");
        
        // Display decoded message
        result.append("Decoded Message : ").append(getDecodedMessage()).append("\n");
        
        return result.toString();
    }
}

