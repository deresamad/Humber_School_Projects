/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab11.exeption;

/**
 *
 * @author pc
 */
public class PositionChecker {

    // Method that checks index and throws exceptions 
    public void position(int index) throws MyException {
        if (index < 0) {
            throw new ArrayIndexOutOfBoundsException("Index cannot be negative");
        } else if (index > 100) {
            throw new MyException(index);
        } else {
            System.out.println("index: " + index);
        }
    }
}

