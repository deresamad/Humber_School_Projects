/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab11.exeption;

/**
 *
 * @author pc
 */

public class MyException extends Exception {
    private int index;

    // Constructor 
    public MyException(int index) {
        this.index = index;
    }

    // Override toString 
    @Override
    public String toString() {
        return "Index " + index + " is invalid";
    }
}
