/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab11.exeption;

import java.util.Scanner;

/**
 *
 * @author pc
 */
public class Lab11Exeption {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PositionChecker checker = new PositionChecker();

        System.out.println("Enter the index");
        int index = scanner.nextInt();

        try {
            checker.position(index);  // method that may throw exceptions
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e.getMessage());  //  negative index
        } catch (MyException e) {
            System.out.println(e);  
        }

        scanner.close();  
    }
}
    

