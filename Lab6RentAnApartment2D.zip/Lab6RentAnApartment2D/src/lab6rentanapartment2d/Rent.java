/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab6rentanapartment2d;

import java.util.Scanner;

/**
 *
 * @author pc
 */
class Rent {
    private double[][] rentTable = {
        {500, 600, 700},    
        {650, 750, 850},   
        {800, 900, 1000},   
        {950, 1050, 1150},  
        {1100, 1200, 1300} 
    };

    public double calculateRent(int floor, int beds) {
        if (floor >= 1 && floor <= 5 && beds >= 0 && beds <= 2) {
            return rentTable[floor - 1][beds];
        } else {
            return -1; 
        }
    }

    public int[] getInput() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter floor and number of bedrooms: ");
        int floor = sc.nextInt();
        int beds = sc.nextInt();
        return new int[]{floor, beds};
    }
}

