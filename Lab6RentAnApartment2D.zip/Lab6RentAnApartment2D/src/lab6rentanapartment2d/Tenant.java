/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab6rentanapartment2d;

/**
 *
 * @author pc
 */
class Tenant {
    private String fullName;
    private int floor;
    private int beds;

    public Tenant(String fullName, int floor, int beds) {
        this.fullName = StringUtility.capitalizeEachWord(fullName);
        this.floor = floor;
        this.beds = beds;
    }

    public String getName() {
        return fullName;
    }

    public int getBeds() {
        return beds;
    }

    public int getFloor() {
        return floor;
    }

    
    public String toString() {
        String type;
        if (beds == 0) {
            type = "Studio apartment";
        } else if (beds == 1) {
            type = "1 bedroom apartment";
        } else {
            type = beds + " bedrooms apartment";
        }
        return fullName + " wants to rent " + type + " on floor number " + floor;
    }
}

