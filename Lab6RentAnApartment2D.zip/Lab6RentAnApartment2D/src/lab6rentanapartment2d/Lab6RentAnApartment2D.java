/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab6rentanapartment2d;

import java.util.Scanner;

/**
 *
 * @author pc
 */
public class Lab6RentAnApartment2D {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        Rent rent = new Rent();

        System.out.print("Enter your name: ");
        String name = sc.nextLine();

        int[] input = rent.getInput();
        int floor = input[0];
        int beds = input[1];

        Tenant tenant = new Tenant(name, floor, beds);
        double rentAmount = rent.calculateRent(floor, beds);

        System.out.println();
        System.out.println(tenant.toString());
        if (rentAmount >= 0) {
            System.out.println("Rent = $" + rentAmount + " per month");
        } else {
            System.out.println("Invalid input. Please try again.");
        }
    }
    }
    
}
