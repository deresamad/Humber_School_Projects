/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg7.inheritance;

/**
 *
 * @author pc
 */

public class MixedFraction extends Fraction {
    private int whole;

    public MixedFraction(int whole, int numerator, int denominator) {
        super((whole * denominator) + numerator, denominator); 
        this.whole = whole;
    }


    @Override
    public int getNumerator() {
        return super.getNumerator(); 
    }

    
    }

