/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab.pkg7.inheritance;

/**
 *
 * @author pc
 */
public class FractionTester {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        Fraction fraction = new Fraction(3, 5);
        MixedFraction mixed1 = new MixedFraction(1, 2, 6);
        MixedFraction mixed2 = new MixedFraction(2, 1, 4);

        System.out.println(fraction);
        System.out.println(mixed1);
        System.out.println(mixed2);
    }
}

    
    

