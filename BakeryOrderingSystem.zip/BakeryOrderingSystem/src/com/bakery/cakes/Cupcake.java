/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bakery.cakes;

/**
 *
 * @author pc
 */
import com.bakery.interfaces.Expirable;
import java.time.LocalDate;

public class Cupcake extends Cake implements Expirable {
    private int count;              // Number of cupcakes (must be 4 or 6)
    private int weight;             // Weight of each cupcake in ounces (1-3 oz)
    private LocalDate expiryDate;   // When these cupcakes expire
    
    /**
     * Constructor for cupcakes with validation
     * @param flavor The flavor of the cupcakes
     * @param quantity How many sets of cupcakes to order
     * @param count Number of cupcakes per set (must be 4 or 6)
     * @param weight Weight per cupcake in ounces (must be 1-3)
     * @throws IllegalArgumentException if count or weight are invalid
     */
    public Cupcake(String flavor, int quantity, int count, int weight) {
        super(flavor, quantity);    // Call parent constructor
        
        // Validate count - only 4 or 6 cupcakes per set allowed
        if (count != 4 && count != 6) {
            throw new IllegalArgumentException("Count must be 4 or 6");
        }
        
        // Validate weight - each cupcake must be between 1-3 ounces
        if (weight < 1 || weight > 3) {
            throw new IllegalArgumentException("Weight must be 1-3 oz");
        }
        
        this.count = count;
        this.weight = weight;
        // Set expiry date to 3 days from today
        this.expiryDate = LocalDate.now().plusDays(3);
    }
    
    /**
     * Calculate price for cupcakes
     * Formula: quantity * (2 * weight * count)
     * This gives a price based on total weight and count
     * @return Total price for this cupcake order
     */
    @Override
    public double calculatePrice() {
        return quantity * (2 * weight * count);
    }
    
    /**
     * Implementation of Expirable interface
     * @return The expiration date for these cupcakes
     */
    @Override
    public LocalDate getExpiryDate() {
        return expiryDate;
    }
    
    /**
     * String representation of the cupcake order
     * @return Formatted string showing price, count, flavor, weight, and expiry
     */
    @Override
    public String toString() {
        return String.format("$%.2f for %d %s cupcakes (%d oz each) - Expires: %s", 
               calculatePrice(), count, flavor, weight, expiryDate);
    }
}
