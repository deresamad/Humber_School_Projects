/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bakery.cakes;

/**
 *
 * @author pc
 */
public class OccasionCake extends Cake {
    private String occasion;    // The type of occasion (Holiday, Birthday, etc.)
    
    // Static 2D array storing occasion types and their corresponding prices
    private static final String[][] OCCASION_PRICES = {
        {"Holiday", "30"},          // Holiday cakes cost $30
        {"Birthday", "40"},         // Birthday cakes cost $40
        {"Anniversary", "50"},      // Anniversary cakes cost $50
        {"Wedding", "60"}           // Wedding cakes cost $60
    };
    
    /**
     * Constructor for occasion cake
     * @param flavor The flavor of the cake
     * @param quantity How many occasion cakes to order
     * @param occasion The type of occasion
     */
    public OccasionCake(String flavor, int quantity, String occasion) {
        super(flavor, quantity);    // Call parent constructor
        this.occasion = occasion;
    }
    
    /**
     * Calculate price for occasion cake
     * Searches through the OCCASION_PRICES array to find matching occasion
     * @return Total price for this occasion cake order
     */
    @Override
    public double calculatePrice() {
        // Loop through all occasion-price pairs
        for (String[] occasionPrice : OCCASION_PRICES) {
            // Check if the occasion matches (case-insensitive)
            if (occasionPrice[0].equalsIgnoreCase(occasion)) {
                // Return quantity * price for this occasion
                return quantity * Double.parseDouble(occasionPrice[1]);
            }
        }
        // Return 0 if occasion not found (shouldn't happen with proper validation)
        return 0;
    }
    
    /**
     * String representation of the occasion cake order
     * @return Formatted string showing price, occasion, and flavor
     */
    @Override
    public String toString() {
        return String.format("$%.2f for %s %s cake", 
               calculatePrice(), occasion, flavor);
    }
}