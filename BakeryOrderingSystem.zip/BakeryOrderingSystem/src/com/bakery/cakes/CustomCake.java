/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bakery.cakes;

/**
 *
 * @author pc
 */
public class CustomCake extends Cake {
    private int layers;     // Number of layers (affects price)
    private int size;       // Size in inches (affects price)
    
    /**
     * Constructor for custom cake
     * @param flavor The flavor of the cake
     * @param quantity How many custom cakes to order
     * @param layers Number of layers (typically 1-4)
     * @param size Size of cake in inches (typically 6, 8, 10, or 12)
     */
    public CustomCake(String flavor, int quantity, int layers, int size) {
        super(flavor, quantity);    // Call parent constructor
        this.layers = layers;
        this.size = size;
    }
    
    /**
     * Calculate price for custom cake
     * Formula: quantity * (base_price + (layers * layer_price) + size)
     * @return Total price for this custom cake order
     */
    @Override
    public double calculatePrice() {
        return quantity * (BASE_PRICE + (layers * LAYER_PRICE) + size);
    }
    
    /**
     * String representation of the custom cake order
     * @return Formatted string showing price, flavor, layers, and size
     */
    @Override
    public String toString() {
        return String.format("$%.2f for %s custom cake (%d layers, %d\")", 
               calculatePrice(), flavor, layers, size);
    }
}