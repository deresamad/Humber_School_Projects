/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bakery.cakes;

/**
 *
 * @author pc
 */
public abstract class Cake {
    // Protected fields - accessible by subclasses
    protected String flavor;        // The flavor of the cake (vanilla, chocolate, etc.)
    protected int quantity;         // How many of this cake type to order
    
    // Static constants - shared across all cake types
    public static final double BASE_PRICE = 30.0;      // Base price for standard cakes
    public static final double LAYER_PRICE = 5.0;      // Additional cost per layer for custom cakes
    
   
    public Cake(String flavor, int quantity) {
        this.flavor = flavor;
        this.quantity = quantity;
    }
    
   
    public abstract double calculatePrice();
}