/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bakery.order;

/**
 *
 * @author pc
 */


import com.bakery.cakes.*;
import javax.swing.*;
import java.util.Random;

public class OrderCake {
    private Cake[] cakes;           // Array to store all cakes in the order
    private int orderNumber;        // Unique order confirmation number
    
    /**
     * Constructor that immediately starts the ordering process
     */
    public OrderCake() {
        startOrderProcess();
    }
    
    /**
     * Initiates the ordering process with error handling
     * Asks user how many cakes they want and creates each one
     */
    private void startOrderProcess() {
        try {
            // Ask user how many cakes they want to order
            String input = JOptionPane.showInputDialog("How many cakes would you like to order?");
            
            // Handle cancel button or empty input
            if (input == null || input.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Order cancelled");
                return;
            }
            
            int numCakes = Integer.parseInt(input);
            
            // Validate positive number
            if (numCakes <= 0) {
                JOptionPane.showMessageDialog(null, "Please enter a positive number");
                return;
            }
            
            // Initialize array to hold all cakes
            cakes = new Cake[numCakes];
            
            // Create each cake based on user selection
            for (int i = 0; i < numCakes; i++) {
                String type = JOptionPane.showInputDialog(
                    "Choose cake type for cake " + (i + 1) + ":\n" +
                    "1. Custom\n" +
                    "2. Occasion\n" + 
                    "3. Cupcake\n\n" +
                    "Enter 1, 2, 3 or type the name:");
                
                // Handle cancel button
                if (type == null) {
                    JOptionPane.showMessageDialog(null, "Order cancelled");
                    return;
                }
                
                // Create the cake and add to array
                cakes[i] = createCake(type.toLowerCase().trim());
            }
            
            // Show order summary and handle confirmation
            showOrderSummary();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number");
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An unexpected error occurred: " + e.getMessage());
        }
    }
    
    /**
     * Creates a specific cake based on user selection and input
     * @param type The type of cake to create (custom, occasion, or cupcake)
     * @return A new Cake object of the specified type
     * @throws IllegalArgumentException if invalid selection or input
     */
    private Cake createCake(String type) {
        // Get flavor for all cake types
        String flavor = JOptionPane.showInputDialog("Enter flavor:");
        if (flavor == null || flavor.trim().isEmpty()) {
            throw new IllegalArgumentException("Flavor cannot be empty");
        }
        
        try {
            switch (type) {
                case "1": 
                case "custom":
                    // Get layers with validation
                    String layersStr = JOptionPane.showInputDialog("Enter number of layers (1-4):");
                    if (layersStr == null) throw new IllegalArgumentException("Layers input cancelled");
                    int layers = Integer.parseInt(layersStr);
                    if (layers < 1 || layers > 4) {
                        throw new IllegalArgumentException("Layers must be between 1-4");
                    }
                    
                    // Get size with validation
                    String sizeStr = JOptionPane.showInputDialog("Enter size in inches (6, 8, 10, or 12):");
                    if (sizeStr == null) throw new IllegalArgumentException("Size input cancelled");
                    int size = Integer.parseInt(sizeStr);
                    if (size != 6 && size != 8 && size != 10 && size != 12) {
                        throw new IllegalArgumentException("Size must be 6, 8, 10, or 12 inches");
                    }
                    
                    return new CustomCake(flavor, 1, layers, size);
                    
                case "2": 
                case "occasion":
                    // Get occasion type
                    String occasion = JOptionPane.showInputDialog(
                        "Enter occasion:\n" +
                        "- Holiday\n" +
                        "- Birthday\n" +
                        "- Anniversary\n" +
                        "- Wedding");
                    if (occasion == null || occasion.trim().isEmpty()) {
                        throw new IllegalArgumentException("Occasion cannot be empty");
                    }
                    
                    // Validate occasion type
                    String[] validOccasions = {"holiday", "birthday", "anniversary", "wedding"};
                    boolean validOccasion = false;
                    for (String valid : validOccasions) {
                        if (valid.equalsIgnoreCase(occasion.trim())) {
                            validOccasion = true;
                            break;
                        }
                    }
                    if (!validOccasion) {
                        throw new IllegalArgumentException("Invalid occasion. Choose Holiday, Birthday, Anniversary, or Wedding");
                    }
                    
                    return new OccasionCake(flavor, 1, occasion);
                    
                case "3": 
                case "cupcake":
                    // Get count with validation
                    String countStr = JOptionPane.showInputDialog("Enter count (4 or 6):");
                    if (countStr == null) throw new IllegalArgumentException("Count input cancelled");
                    int count = Integer.parseInt(countStr);
                    
                    // Get weight with validation
                    String weightStr = JOptionPane.showInputDialog("Enter weight per cupcake (1-3 oz):");
                    if (weightStr == null) throw new IllegalArgumentException("Weight input cancelled");
                    int weight = Integer.parseInt(weightStr);
                    
                    return new Cupcake(flavor, 1, count, weight);
                    
                default:
                    throw new IllegalArgumentException("Invalid cake type selection");
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Please enter valid numbers");
        }
    }
    
    /**
     * Displays order summary and handles order confirmation
     * Shows all cakes, total price, and asks for confirmation
     */
    private void showOrderSummary() {
        StringBuilder summary = new StringBuilder("=== ORDER SUMMARY ===\n\n");
        double total = 0;
        
        // Add each cake to the summary and calculate total
        for (int i = 0; i < cakes.length; i++) {
            summary.append("Cake ").append(i + 1).append(": ")
                   .append(cakes[i].toString()).append("\n");
            total += cakes[i].calculatePrice();
        }
        
        // Add total price
        summary.append("\n").append("=".repeat(30)).append("\n");
        summary.append("TOTAL: $").append(String.format("%.2f", total));
        
        // Show confirmation dialog
        int choice = JOptionPane.showConfirmDialog(null, 
            summary.toString() + "\n\nConfirm this order?", 
            "Order Review", 
            JOptionPane.YES_NO_OPTION);
        
        if (choice == JOptionPane.YES_OPTION) {
            // Generate random order number and confirm
            orderNumber = new Random().nextInt(900000) + 100000;
            JOptionPane.showMessageDialog(null, 
                "✓ Order confirmed!\n\n" +
                "Confirmation Number: #" + orderNumber + "\n" +
                "Total: $" + String.format("%.2f", total) + "\n\n" +
                "Thank you for your order!");
        } else {
            JOptionPane.showMessageDialog(null, "Order cancelled");
        }
    }
}