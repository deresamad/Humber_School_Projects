/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bakeryorderingsystem;

import com.bakery.order.OrderCake;

/**
 *
 * @author pc
 */
    /**
     * @param args the command line arguments
     */
    public class BakeryOrderingSystem {
    public static void main(String[] args) {
        new OrderCake();
    }
}

