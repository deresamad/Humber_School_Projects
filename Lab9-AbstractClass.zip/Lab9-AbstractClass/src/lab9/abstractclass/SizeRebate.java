/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab9.abstractclass;

/**
 *
 * @author pc
 */
public class SizeRebate extends Rebate {
    private int minQty;
    private double percentDiscount;

    public SizeRebate(String itemName, double itemPrice, int itemCount, int minQty, double percentDiscount) {
        super(itemName, itemPrice, itemCount);
        this.minQty = minQty;
        this.percentDiscount = percentDiscount;
    }

    @Override
    public double calculateDiscount() {
        if (itemCount > minQty) {
            return (itemPrice * itemCount) * (percentDiscount / 100);
        } else {
            return 0.0;
        }
    }

    @Override
    public String toString() {
        return super.toString() +
               "Rebate Type: Size Rebate\n" +
               "Minimum Qty for Discount: " + minQty + 
               "\nDiscount Percentage: " + percentDiscount + "%\n";
    }
}

