/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab9.abstractclass;

/**
 *
 * @author pc
 */
public class RebateTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Rebate[] rebates = new Rebate[6];

        rebates[0] = new BOGORebate("Hair mask", 10.0, 1);                    
        rebates[1] = new BOGORebate("Hair shampoo", 15.0, 4);                
        rebates[2] = new BOGORebate("Hair oil", 5.0, 5);                     
        rebates[3] = new SizeRebate("Hair essentials", 15.0, 10, 5, 10);     
        rebates[4] = new SizeRebate("Bath essentials", 20.0, 15, 10, 20);    
        rebates[5] = new SizeRebate("Body essentials", 10.0, 16, 20, 30);    

        System.out.printf("%-7s %-18s %-14s %-12s\n", "Count", "Item bought", "Unit price", "Total price");
        System.out.println("---------------------------------------------------------------");

        for (Rebate r : rebates) {
            System.out.printf("%-7d %-18s $%-13.2f $%-11.2f\n",
                    r.itemCount, r.itemName, r.itemPrice, r.getTotalPrice());
        }
    }
}

   
