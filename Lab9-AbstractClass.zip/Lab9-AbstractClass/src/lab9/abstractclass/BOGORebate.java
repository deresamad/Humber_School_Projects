/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab9.abstractclass;

/**
 *
 * @author pc
 */
public class BOGORebate extends Rebate {

    public BOGORebate(String itemName, double itemPrice, int itemCount) {
        super(itemName, itemPrice, itemCount);
    }

    @Override
    public double calculateDiscount() {
        int freeItems = itemCount / 2;
        return freeItems * itemPrice;
    }
}
