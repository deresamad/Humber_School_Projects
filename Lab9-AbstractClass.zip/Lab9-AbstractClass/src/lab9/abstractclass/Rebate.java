/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab9.abstractclass;

/**
 *
 * @author pc
 */
public abstract class Rebate {
    protected String itemName;
    protected double itemPrice;
    protected int itemCount;

    public Rebate(String itemName, double itemPrice, int itemCount) {
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.itemCount = itemCount;
    }

    // Abstract method for calculating discount
    public abstract double calculateDiscount();

    // Method to calculate total cost after rebate
    public double getTotalPrice() {
        return (itemPrice * itemCount) - calculateDiscount();
    }

    @Override
    public String toString() {
        return "Item: " + itemName +
               "\nPrice: $" + itemPrice +
               "\nQuantity: " + itemCount +
               "\nDiscount: $" + String.format("%.2f", calculateDiscount()) +
               "\nTotal Price after Rebate: $" + String.format("%.2f", getTotalPrice()) + "\n";
    }
}


